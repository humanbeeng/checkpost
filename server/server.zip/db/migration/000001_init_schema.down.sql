drop table if exists request;

drop table if exists response;

drop table if exists file_attachment;

drop table if exists endpoint;

drop table if exists "user";

drop type if exists http_method;

drop type if exists plan;
